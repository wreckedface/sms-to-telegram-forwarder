# SMS to Telegram Forwarder — FINAL v4

Production-oriented Android build containing:
- SMS receiver
- encrypted Telegram bot token with Android Keystore
- automatic Telegram chat-ID discovery
- connection test
- sender and keyword filtering
- duplicate protection
- optional code redaction
- local delivery history
- delivery statistics
- failed-message retry queue using Android WorkManager
- manual retry action
- clear local data action
- no paid SMS gateway and no required custom backend

## Build
Open the project in Android Studio, sync Gradle, and build a debug APK or signed release.

## Setup
Create a bot with @BotFather. Start the bot and send it a message. Enter the bot token, use Auto-discover chat ID, save, enable forwarding, and test.

## Production notes
Before publishing to Google Play, review Google's current SMS permission and default-handler eligibility requirements. SMS permissions are sensitive and Play distribution may require the app's core functionality to qualify. Test on a real Android device across reboot, offline/online transitions, multipart SMS, and manufacturer battery restrictions.

## Privacy
SMS is processed on-device and sent directly to Telegram when a forwarding rule allows it. The app does not require a custom server. Never share the bot token and only use forwarding on devices/messages you are authorized to access.
